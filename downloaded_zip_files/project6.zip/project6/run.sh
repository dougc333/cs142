#!/bin/bash

node webServer.js & npm run build:w

