#!/bin/bash

ps aux | grep -v grep | grep mongod
