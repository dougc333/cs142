#!/bin/bash

brew services stop mongodb-community@4.2
