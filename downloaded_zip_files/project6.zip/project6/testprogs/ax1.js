import axios from 'axios';


console.log("asdf")

axios.get("http://localhost"
        [, config])