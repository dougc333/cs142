function myObj(){};
myObj.color="green";
myObj.age=100;
var my = function(){};
my.color="green";
my.age=10;
//is there a diff between the 2? 
console.log(myObj);
console.log(my);